<?php
/**
 * The template for displaying registration page
 *
 * This is the template that displays registration page by default. Please note that
 * this is the WordPress construct of pages: specifically, posts with a post
 * type of `page`.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Visitor_Management_System
 */

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

get_header();

$errors = array();

if ( isset( $_POST['signup'] ) ) {

    error_log( 'Form submitted' );
    error_log( 'POST data: ' . print_r( $_POST, true ) ); 

    // Check if the terms checkbox is ticked
    if ( ! isset( $_POST['remember_me'] ) ) {
        $errors[] = 'You must agree to the terms of use.';
    }

    // Proceed if no errors
    if ( empty( $errors ) ) {
        global $wpdb;

        $first_name    = sanitize_text_field( $_POST['first_name'] );
        $last_name     = sanitize_text_field( $_POST['last_name'] );
        $member_number = sanitize_user( $_POST['member_number'] );
        $user_email    = sanitize_email( $_POST['email'] );
        $user_number   = sanitize_text_field( $_POST['user_number'] );
        $user_pass     = sanitize_text_field( $_POST['password'] );

        // ✅ Check if member number already exists
        $existing_member = $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} 
             WHERE meta_key = 'member_number' AND meta_value = %s 
             LIMIT 1",
            $member_number
        ) );

        if ( $existing_member ) {
            $errors[] = 'This member number is already registered. Please use a unique member number.';
        }
    }

    if ( empty( $errors ) ) {
        // Generate user_login as firstname.lastname in lowercase
        $user_login = strtolower( $first_name . '.' . $last_name );

        // Ensure it's a valid login and unique
        $user_login = sanitize_user( $user_login, true );
        $original_login = $user_login;
        $counter = 1;
        while ( username_exists( $user_login ) ) {
            $user_login = $original_login . $counter;
            $counter++;
        }

        $data = array(
            'user_login' => $user_login,
            'user_email' => $user_email,
            'user_pass'  => $user_pass,
            'role'       => 'member',
            'meta_input' => array(
                'first_name'           => $first_name,
                'last_name'            => $last_name,
                'member_number'        => $member_number,
                'phone_number'         => $user_number,
                'receive_messages'     => 'yes',
                'receive_emails'       => 'yes',
                'registration_status'  => 'pending',
                'show_admin_bar_front' => 'false',
            ),
        );

        $user_id = wp_insert_user( wp_slash( $data ) );

        if ( ! is_wp_error( $user_id ) ) {
            $success_message = 'The account for ' . $user_login . ' has been successfully registered.';

            // 1. Email Admin
            $admin_email   = get_option( 'admin_email' );
            $admin_subject = 'New user registration waiting for approval';
            $admin_message = "Hello Admin,\n\n"
                . "A new user has registered and is pending approval:\n\n"
                . "Name: {$first_name} {$last_name}\n"
                . "Username: {$user_login}\n"
                . "Email: {$user_email}\n\n"
                . "Member Number: {$member_number}\n"
                . "Please log into the system to approve or deny this registration.\n\n"
                . "Nyeri Club Visitor Management System";
            wp_mail( $admin_email, $admin_subject, $admin_message );

            // 2. Email User
            $user_subject = 'Your registration is pending approval';
            $user_message = "Hello {$first_name},\n\n"
                . "Thank you for registering with us!\n\n"
                . "Your account details are as follows:\n"
                . "Username: {$user_login}\n"
                . "Email: {$user_email}\n\n"
                . "Please note that your account is pending approval by our Managerial team. "
                . "Once approved, you will receive an email notification confirming you can log in.\n\n"
                . "Thank you for your patience, and welcome aboard!\n\n"
                . "Best regards,\nNyeri Club Visitor Management System";
            wp_mail( $user_email, $user_subject, $user_message );

            // 3. SMS User
            $sms_message = "Hello {$first_name}, your registration is pending approval. "
                         . "You’ll be notified once approved. - Nyeri Club VMS";
            \WyllyMk\VMS\VMS_NotificationManager::send_sms( $user_number, $sms_message, $user_id, 'member' );

        } else {
            $error_code    = array_key_first( $user_id->errors );
            $error_message = $user_id->errors[ $error_code ][0];
            $errors[]      = $error_message;
        }
    }
}

?>
<section class="register-content" x-data="{ page: 'register' }">
    <!-- ===== Page Wrapper Start ===== -->
    <div class="relative p-6 bg-white z-1 dark:bg-gray-900 sm:p-0">
        <div class="flex flex-col justify-center w-full h-svh dark:bg-gray-900 sm:p-0 lg:flex-row">
            <!-- Form -->
            <div class="flex flex-col flex-1 w-full lg:w-1/2">
                <div class="w-full max-w-md pt-5 mx-auto sm:py-10">
                    <a href="<?php echo esc_url( home_url( '/dashboard' ) ); ?>"
                        class="inline-flex items-center text-sm text-gray-500 transition-colors hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                        <svg class="stroke-current" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                            viewBox="0 0 20 20" fill="none">
                            <path d="M12.7083 5L7.5 10.2083L12.7083 15.4167" stroke="" stroke-width="1.5"
                                stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        <?php esc_html_e( 'Back to dashboard', 'vms' ); ?>
                    </a>
                </div>
                <div class="flex flex-col justify-center flex-1 w-full max-w-md mx-auto">
                    <!-- Error Alert -->
                    <?php if ( ! empty( $errors ) ) : ?>
                    <div class="flex items-center justify-between p-4 mb-4 text-red-700 bg-red-100 border-l-4 border-red-500"
                        role="alert">
                        <div>
                            <strong><?php esc_html_e( 'Warning!', 'vms' ); ?></strong>
                            <?php foreach ( $errors as $error ) : ?>
                            &nbsp; <p class="text-sm"><?php echo $error; ?></p>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="float-right text-red-700 hover:text-red-900"
                            onclick="this.parentElement.style.display='none';">×</button>
                    </div>
                    <?php endif; ?>
                    <!-- Success Alert -->
                    <?php if ( isset( $success_message ) ) : ?>
                    <div class="flex items-center justify-between p-4 mb-4 text-green-700 bg-green-100 border-l-4 border-green-500"
                        role="alert">
                        <div>
                            <strong><?php esc_html_e( 'Success!', 'vms' ); ?></strong>
                            <p class="text-sm"><?php echo $success_message; ?></p>
                        </div>
                        <button type="button" class="float-right text-red-700 hover:text-red-900"
                            onclick="this.parentElement.style.display='none';">×</button>
                    </div>
                    <?php endif; ?>
                    <!-- End of Alert -->
                    <div class="mb-5 sm:mb-8">
                        <h1 class="mb-2 font-semibold text-gray-800 text-title-sm dark:text-white/90 sm:text-title-md">
                            <?php esc_html_e( 'Sign Up', 'vms' ); ?>
                        </h1>
                        <p class="text-sm text-gray-500 dark:text-gray-400">
                            <?php esc_html_e( 'Enter your details to sign up!', 'vms' ); ?>
                        </p>
                    </div>
                    <div>
                        <form action="" method="post">
                            <div class="space-y-5">
                                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                                    <!-- First Name -->
                                    <div class="sm:col-span-1">
                                        <label
                                            class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                            <?php esc_html_e( 'First Name', 'vms' ); ?>
                                            <span class="text-error-500">*</span>
                                        </label>
                                        <input name="first_name" type="text" id="fname"
                                            placeholder="Enter your first name"
                                            class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                            required />
                                    </div>
                                    <!-- Last Name -->
                                    <div class="sm:col-span-1">
                                        <label
                                            class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                            <?php esc_html_e( 'Last Name', 'vms' ); ?>
                                            <span class="text-error-500">*</span>
                                        </label>
                                        <input name="last_name" type="text" id="lname"
                                            placeholder="Enter your last name"
                                            class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                            required />
                                    </div>
                                </div>
                                <!-- Phone & Username -->
                                <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                                    <!-- Phone Number -->
                                    <div>
                                        <label
                                            class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                            <?php esc_html_e( 'Phone Number', 'vms' ); ?>
                                            <span class="text-error-500">*</span>
                                        </label>
                                        <input name="user_number" type="text" placeholder="Phone Number"
                                            id="user_number" class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300
                                        bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs
                                        placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden
                                        focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900
                                        dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                            required />
                                    </div>
                                    <!-- Member Number -->
                                    <div>
                                        <label
                                            class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                            <?php esc_html_e( 'Member Number', 'vms' ); ?>
                                            <span class="text-error-500">*</span>
                                        </label>
                                        <input name="member_number" type="text" placeholder="Member Number"
                                            id="member_number" class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300
                                        bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs
                                        placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden
                                        focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900
                                        dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                            required />
                                    </div>
                                </div>
                                <!-- Email -->
                                <div>
                                    <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                        <?php esc_html_e( 'Email', 'vms' ); ?>
                                        <span class="text-error-500">*</span>
                                    </label>
                                    <input name="email" type="email" id="email" placeholder="Enter your email"
                                        class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                        required />
                                </div>
                                <!-- Password -->
                                <div>
                                    <label class="mb-1.5 block text-sm font-medium text-gray-700 dark:text-gray-400">
                                        <?php esc_html_e( 'Password', 'vms' ); ?>
                                        <span class="text-error-500">*</span>
                                    </label>
                                    <div x-data="{ showPassword: false }" class="relative">
                                        <input :type="showPassword ? 'text' : 'password'"
                                            placeholder="Enter your password" name="password"
                                            class="dark:bg-dark-900 h-11 w-full rounded-lg border border-gray-300 bg-transparent py-2.5 pl-4 pr-11 text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"
                                            required />
                                        <span @click="showPassword = !showPassword"
                                            class="absolute z-30 text-gray-500 -translate-y-1/2 cursor-pointer right-4 top-1/2 dark:text-gray-400">
                                            <svg x-show="!showPassword" class="fill-current" width="20" height="20"
                                                viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M10.0002 13.8619C7.23361 13.8619 4.86803 12.1372 3.92328 9.70241C4.86804 7.26761 7.23361 5.54297 10.0002 5.54297C12.7667 5.54297 15.1323 7.26762 16.0771 9.70243C15.1323 12.1372 12.7667 13.8619 10.0002 13.8619ZM10.0002 4.04297C6.48191 4.04297 3.49489 6.30917 2.4155 9.4593C2.3615 9.61687 2.3615 9.78794 2.41549 9.94552C3.49488 13.0957 6.48191 15.3619 10.0002 15.3619C13.5184 15.3619 16.5055 13.0957 17.5849 9.94555C17.6389 9.78797 17.6389 9.6169 17.5849 9.45932C16.5055 6.30919 13.5184 4.04297 10.0002 4.04297ZM9.99151 7.84413C8.96527 7.84413 8.13333 8.67606 8.13333 9.70231C8.13333 10.7286 8.96527 11.5605 9.99151 11.5605H10.0064C11.0326 11.5605 11.8646 10.7286 11.8646 9.70231C11.8646 8.67606 11.0326 7.84413 10.0064 7.84413H9.99151Z"
                                                    fill="#98A2B3" />
                                            </svg>
                                            <svg x-show="showPassword" class="fill-current" width="20" height="20"
                                                viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M4.63803 3.57709C4.34513 3.2842 3.87026 3.2842 3.57737 3.57709C3.28447 3.86999 3.28447 4.34486 3.57737 4.63775L4.85323 5.91362C3.74609 6.84199 2.89363 8.06395 2.4155 9.45936C2.3615 9.61694 2.3615 9.78801 2.41549 9.94558C3.49488 13.0957 6.48191 15.3619 10.0002 15.3619C11.255 15.3619 12.4422 15.0737 13.4994 14.5598L15.3625 16.4229C15.6554 16.7158 16.1302 16.7158 16.4231 16.4229C16.716 16.13 16.716 15.6551 16.4231 15.3622L4.63803 3.57709ZM12.3608 13.4212L10.4475 11.5079C10.3061 11.5423 10.1584 11.5606 10.0064 11.5606H9.99151C8.96527 11.5606 8.13333 10.7286 8.13333 9.70237C8.13333 9.5461 8.15262 9.39434 8.18895 9.24933L5.91885 6.97923C5.03505 7.69015 4.34057 8.62704 3.92328 9.70247C4.86803 12.1373 7.23361 13.8619 10.0002 13.8619C10.8326 13.8619 11.6287 13.7058 12.3608 13.4212ZM16.0771 9.70249C15.7843 10.4569 15.3552 11.1432 14.8199 11.7311L15.8813 12.7925C16.6329 11.9813 17.2187 11.0143 17.5849 9.94561C17.6389 9.78803 17.6389 9.61696 17.5849 9.45938C16.5055 6.30925 13.5184 4.04303 10.0002 4.04303C9.13525 4.04303 8.30244 4.17999 7.52218 4.43338L8.75139 5.66259C9.1556 5.58413 9.57311 5.54303 10.0002 5.54303C12.7667 5.54303 15.1323 7.26768 16.0771 9.70249Z"
                                                    fill="#98A2B3" />
                                            </svg>
                                        </span>
                                    </div>
                                </div>
                                <!-- Checkbox -->
                                <div>
                                    <div x-data="{ checkboxToggle: false }">
                                        <label for="checkboxLabelOne"
                                            class="flex items-start text-sm font-normal text-gray-700 cursor-pointer select-none dark:text-gray-400">
                                            <div class="relative">
                                                <input name="remember_me" type="checkbox" id="checkboxLabelOne"
                                                    class="sr-only" @change="checkboxToggle = !checkboxToggle" />
                                                <div :class="checkboxToggle ? 'border-brand-500 bg-brand-500' : 'bg-transparent border-gray-300 dark:border-gray-700'"
                                                    class="mr-3 flex h-5 w-5 items-center justify-center rounded-md border-[1.25px]">
                                                    <span :class="checkboxToggle ? '' : 'opacity-0'">
                                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M11.6666 3.5L5.24992 9.91667L2.33325 7"
                                                                stroke="white" stroke-width="1.94437"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </span>
                                                </div>
                                            </div>
                                            <p class="inline-block font-normal text-gray-500 dark:text-gray-400">
                                                <?php esc_html_e( 'By creating an account means you agree to the', 'vms' ); ?>
                                                <span class="text-gray-800 dark:text-white/90">
                                                    <?php esc_html_e( 'Terms and Conditions,', 'vms' ); ?>
                                                </span>
                                                <?php esc_html_e( 'and our', 'vms' ); ?>
                                                <span class="text-gray-800 dark:text-white">
                                                    <?php esc_html_e( 'Privacy Policy', 'vms' ); ?>
                                                </span>
                                            </p>
                                        </label>
                                    </div>
                                </div>
                                <!-- Button -->
                                <div>
                                    <button type="submit" name="signup"
                                        class="flex items-center justify-center w-full px-4 py-3 text-sm font-medium text-white transition rounded-lg bg-brand-500 shadow-theme-xs hover:bg-brand-600">
                                        <?php esc_html_e( 'Sign Up', 'vms' ); ?>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div class="mt-5">
                            <p class="text-sm font-normal text-center text-gray-700 dark:text-gray-400 sm:text-start">
                                <?php esc_html_e( ' Already have an account?', 'vms' ); ?>
                                <a href="<?php echo esc_url( home_url( '/login' ) ); ?>"
                                    class="text-brand-500 hover:text-brand-600 dark:text-brand-400">
                                    <?php esc_html_e( 'Sign In', 'vms' ); ?>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="relative items-center hidden w-full h-full bg-brand-950 dark:bg-white/5 lg:grid lg:w-1/2">
                <div class="flex items-center justify-center z-1">
                    <!-- ===== Common Grid Shape Start ===== -->
                    <?php get_template_part( 'template-parts/content/content', 'grid' ); ?>
                    <div class="flex flex-col items-center max-w-sm">
                        <a href="<?php echo esc_url( home_url(  ) ); ?>" class="block mb-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/logo.png"
                                alt="Logo" />
                        </a>
                        <h2 class="text-center text-2xl font-bold font-oswald text-gray-300 dark:text-gray-100 mb-2">
                            <?php esc_html_e( 'Nyeri Club Visitor Management System', 'vms' ); ?>
                        </h2>
                        <p class="text-center text-gray-500 dark:text-white/60">
                            <?php esc_html_e( 'Secure access to manage visitors, members, and reciprocating members — anytime, anywhere.', 'vms' ); ?>
                        </p>
                    </div>
                </div>
            </div>
            <!-- Toggler -->
            <div class="fixed z-50 hidden bottom-6 right-6 sm:block">
                <button
                    class="inline-flex items-center justify-center text-white transition-colors rounded-full size-14 bg-brand-500 hover:bg-brand-600"
                    @click.prevent="darkMode = !darkMode">
                    <svg class="hidden fill-current dark:block" width="20" height="20" viewBox="0 0 20 20" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M9.99998 1.5415C10.4142 1.5415 10.75 1.87729 10.75 2.2915V3.5415C10.75 3.95572 10.4142 4.2915 9.99998 4.2915C9.58577 4.2915 9.24998 3.95572 9.24998 3.5415V2.2915C9.24998 1.87729 9.58577 1.5415 9.99998 1.5415ZM10.0009 6.79327C8.22978 6.79327 6.79402 8.22904 6.79402 10.0001C6.79402 11.7712 8.22978 13.207 10.0009 13.207C11.772 13.207 13.2078 11.7712 13.2078 10.0001C13.2078 8.22904 11.772 6.79327 10.0009 6.79327ZM5.29402 10.0001C5.29402 7.40061 7.40135 5.29327 10.0009 5.29327C12.6004 5.29327 14.7078 7.40061 14.7078 10.0001C14.7078 12.5997 12.6004 14.707 10.0009 14.707C7.40135 14.707 5.29402 12.5997 5.29402 10.0001ZM15.9813 5.08035C16.2742 4.78746 16.2742 4.31258 15.9813 4.01969C15.6884 3.7268 15.2135 3.7268 14.9207 4.01969L14.0368 4.90357C13.7439 5.19647 13.7439 5.67134 14.0368 5.96423C14.3297 6.25713 14.8045 6.25713 15.0974 5.96423L15.9813 5.08035ZM18.4577 10.0001C18.4577 10.4143 18.1219 10.7501 17.7077 10.7501H16.4577C16.0435 10.7501 15.7077 10.4143 15.7077 10.0001C15.7077 9.58592 16.0435 9.25013 16.4577 9.25013H17.7077C18.1219 9.25013 18.4577 9.58592 18.4577 10.0001ZM14.9207 15.9806C15.2135 16.2735 15.6884 16.2735 15.9813 15.9806C16.2742 15.6877 16.2742 15.2128 15.9813 14.9199L15.0974 14.036C14.8045 13.7431 14.3297 13.7431 14.0368 14.036C13.7439 14.3289 13.7439 14.8038 14.0368 15.0967L14.9207 15.9806ZM9.99998 15.7088C10.4142 15.7088 10.75 16.0445 10.75 16.4588V17.7088C10.75 18.123 10.4142 18.4588 9.99998 18.4588C9.58577 18.4588 9.24998 18.123 9.24998 17.7088V16.4588C9.24998 16.0445 9.58577 15.7088 9.99998 15.7088ZM5.96356 15.0972C6.25646 14.8043 6.25646 14.3295 5.96356 14.0366C5.67067 13.7437 5.1958 13.7437 4.9029 14.0366L4.01902 14.9204C3.72613 15.2133 3.72613 15.6882 4.01902 15.9811C4.31191 16.274 4.78679 16.274 5.07968 15.9811L5.96356 15.0972ZM4.29224 10.0001C4.29224 10.4143 3.95645 10.7501 3.54224 10.7501H2.29224C1.87802 10.7501 1.54224 10.4143 1.54224 10.0001C1.54224 9.58592 1.87802 9.25013 2.29224 9.25013H3.54224C3.95645 9.25013 4.29224 9.58592 4.29224 10.0001ZM4.9029 5.9637C5.1958 6.25659 5.67067 6.25659 5.96356 5.9637C6.25646 5.6708 6.25646 5.19593 5.96356 4.90303L5.07968 4.01915C4.78679 3.72626 4.31191 3.72626 4.01902 4.01915C3.72613 4.31204 3.72613 4.78692 4.01902 5.07981L4.9029 5.9637Z"
                            fill="" />
                    </svg>
                    <svg class="fill-current dark:hidden" width="20" height="20" viewBox="0 0 20 20" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M17.4547 11.97L18.1799 12.1611C18.265 11.8383 18.1265 11.4982 17.8401 11.3266C17.5538 11.1551 17.1885 11.1934 16.944 11.4207L17.4547 11.97ZM8.0306 2.5459L8.57989 3.05657C8.80718 2.81209 8.84554 2.44682 8.67398 2.16046C8.50243 1.8741 8.16227 1.73559 7.83948 1.82066L8.0306 2.5459ZM12.9154 13.0035C9.64678 13.0035 6.99707 10.3538 6.99707 7.08524H5.49707C5.49707 11.1823 8.81835 14.5035 12.9154 14.5035V13.0035ZM16.944 11.4207C15.8869 12.4035 14.4721 13.0035 12.9154 13.0035V14.5035C14.8657 14.5035 16.6418 13.7499 17.9654 12.5193L16.944 11.4207ZM16.7295 11.7789C15.9437 14.7607 13.2277 16.9586 10.0003 16.9586V18.4586C13.9257 18.4586 17.2249 15.7853 18.1799 12.1611L16.7295 11.7789ZM10.0003 16.9586C6.15734 16.9586 3.04199 13.8433 3.04199 10.0003H1.54199C1.54199 14.6717 5.32892 18.4586 10.0003 18.4586V16.9586ZM3.04199 10.0003C3.04199 6.77289 5.23988 4.05695 8.22173 3.27114L7.83948 1.82066C4.21532 2.77574 1.54199 6.07486 1.54199 10.0003H3.04199ZM6.99707 7.08524C6.99707 5.52854 7.5971 4.11366 8.57989 3.05657L7.48132 2.03522C6.25073 3.35885 5.49707 5.13487 5.49707 7.08524H6.99707Z"
                            fill="" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <!-- ===== Page Wrapper End ===== -->
</section>
<?php get_footer(); ?>