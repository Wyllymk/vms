<?php
/**
 * The template for displaying the dashboard page
 *
 * @package Visitor_Management_System
 */

// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

// Check if the current user has appropriate permissions
if ( ! ( current_user_can( 'administrator' ) || current_user_can( 'general_manager' ) || 
         current_user_can( 'chairman' ) || current_user_can( 'reception' ) || 
         current_user_can( 'gate' ) ) ) {
    wp_redirect( home_url() );
    exit;
}

// Get the current user info
$current_user = wp_get_current_user();
$user_name = $current_user->display_name;

// Get time-based greeting
$hour = (int) date('H');
if ($hour < 12) {
    $greeting = __('Good Morning', 'vms');
    $emoji = '🌅';
} elseif ($hour < 18) {
    $greeting = __('Good Afternoon', 'vms');
    $emoji = '☀️';
} else {
    $greeting = __('Good Evening', 'vms');
    $emoji = '🌙';
}

get_header();

global $wpdb;

// Get today's statistics
$today = current_time('Y-m-d');
$guests_table = \WyllyMk\VMS\VMS_Config::get_table_name(\WyllyMk\VMS\VMS_Config::GUESTS_TABLE);
$guest_visits_table = \WyllyMk\VMS\VMS_Config::get_table_name(\WyllyMk\VMS\VMS_Config::GUEST_VISITS_TABLE);
$a_guest_visits_table = \WyllyMk\VMS\VMS_Config::get_table_name(\WyllyMk\VMS\VMS_Config::A_GUEST_VISITS_TABLE);
$supplier_visits_table = \WyllyMk\VMS\VMS_Config::get_table_name(\WyllyMk\VMS\VMS_Config::SUPPLIER_VISITS_TABLE);
$recip_visits_table = \WyllyMk\VMS\VMS_Config::get_table_name(\WyllyMk\VMS\VMS_Config::RECIP_MEMBERS_VISITS_TABLE);

// Today's visits count
$today_visits = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM (
        SELECT id FROM {$guest_visits_table} WHERE visit_date = %s
        UNION ALL
        SELECT id FROM {$a_guest_visits_table} WHERE visit_date = %s
        UNION ALL
        SELECT id FROM {$supplier_visits_table} WHERE visit_date = %s
        UNION ALL
        SELECT id FROM {$recip_visits_table} WHERE visit_date = %s
    ) AS combined",
    $today, $today, $today, $today
));

// Currently signed in (sign_in_time IS NOT NULL AND sign_out_time IS NULL)
$currently_signed_in = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM (
        SELECT id FROM {$guest_visits_table} 
        WHERE visit_date = %s AND sign_in_time IS NOT NULL AND sign_out_time IS NULL
        UNION ALL
        SELECT id FROM {$a_guest_visits_table} 
        WHERE visit_date = %s AND sign_in_time IS NOT NULL AND sign_out_time IS NULL
        UNION ALL
        SELECT id FROM {$supplier_visits_table} 
        WHERE visit_date = %s AND sign_in_time IS NOT NULL AND sign_out_time IS NULL
        UNION ALL
        SELECT id FROM {$recip_visits_table} 
        WHERE visit_date = %s AND sign_in_time IS NOT NULL AND sign_out_time IS NULL
    ) AS signed_in",
    $today, $today, $today, $today
));

// This week's visits
$week_start = date('Y-m-d', strtotime('monday this week'));
$week_end = date('Y-m-d', strtotime('sunday this week'));
$week_visits = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM (
        SELECT id FROM {$guest_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$a_guest_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$supplier_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$recip_visits_table} WHERE visit_date BETWEEN %s AND %s
    ) AS combined",
    $week_start, $week_end, $week_start, $week_end, $week_start, $week_end, $week_start, $week_end
));

// This month's visits
$month_start = date('Y-m-01');
$month_end = date('Y-m-t');
$month_visits = (int) $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM (
        SELECT id FROM {$guest_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$a_guest_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$supplier_visits_table} WHERE visit_date BETWEEN %s AND %s
        UNION ALL
        SELECT id FROM {$recip_visits_table} WHERE visit_date BETWEEN %s AND %s
    ) AS combined",
    $month_start, $month_end, $month_start, $month_end, $month_start, $month_end, $month_start, $month_end
));

// Get recent check-ins (last 5)
$recent_checkins = $wpdb->get_results($wpdb->prepare(
    "SELECT 
        g.first_name, g.last_name, gv.sign_in_time, 'Guest' as type
    FROM {$guest_visits_table} gv
    INNER JOIN {$guests_table} g ON gv.guest_id = g.id
    WHERE gv.visit_date = %s AND gv.sign_in_time IS NOT NULL
    ORDER BY gv.sign_in_time DESC
    LIMIT 5",
    $today
));

?>

<section x-data="{ page: 'dashboard'}">
    <!-- ===== Page Wrapper Start ===== -->
    <div class="flex h-svh overflow-hidden">
        <!-- ===== Sidebar Start ===== -->
        <?php get_template_part( 'template-parts/content/content', 'sidebar' ); ?>
        <!-- ===== Sidebar End ===== -->

        <!-- ===== Content Area Start ===== -->
        <div class="relative flex flex-col flex-1 overflow-x-hidden overflow-y-auto">
            <!-- Small Device Overlay Start -->
            <?php get_template_part( 'template-parts/content/content', 'overlay' ); ?>
            <!-- Small Device Overlay End -->

            <!-- ===== Header Start ===== -->
            <?php get_template_part( 'template-parts/content/content', 'header' ); ?>
            <!-- ===== Header End ===== -->

            <!-- ===== Main Content Start ===== -->
            <main>
                <div class="p-4 mx-auto max-w-(--breakpoint-2xl) min-h-screen md:p-6">

                    <!-- Welcome Banner -->
                    <div class="mb-6 rounded-2xl bg-gradient-to-r from-brand-500 to-brand-600 p-6 text-white shadow-lg">
                        <div class="flex items-center justify-between flex-wrap gap-4">
                            <div>
                                <h1 class="text-2xl md:text-3xl font-bold mb-2">
                                    <?php echo esc_html($greeting); ?>, <?php echo esc_html($user_name); ?>!
                                    <?php echo $emoji; ?>
                                </h1>
                                <p class="text-white/90 text-sm md:text-base">
                                    <?php echo esc_html(date('l, F j, Y')); ?> •
                                    <span class="font-semibold"><?php echo esc_html($currently_signed_in); ?></span>
                                    <?php esc_html_e('visitors currently on premises', 'vms'); ?>
                                </p>
                            </div>
                            <div class="flex gap-3">
                                <a href="<?php echo esc_url(home_url('/reports')); ?>"
                                    class="inline-flex items-center gap-2 px-4 py-2.5 bg-white text-brand-600 rounded-lg font-medium hover:bg-white/90 transition shadow-md hover:shadow-lg">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                                        </path>
                                    </svg>
                                    <?php esc_html_e('View Reports', 'vms'); ?>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Stats Grid -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6">
                        <!-- Today's Visits -->
                        <div
                            class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] hover:shadow-lg transition-shadow">
                            <div class="flex items-center justify-between mb-4">
                                <div
                                    class="flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/20">
                                    <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                </div>
                            </div>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mb-1">
                                <?php echo esc_html($today_visits); ?></h3>
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                <?php esc_html_e("Today's Visits", 'vms'); ?></p>
                        </div>

                        <!-- Currently Signed In -->
                        <div
                            class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] hover:shadow-lg transition-shadow">
                            <div class="flex items-center justify-between mb-4">
                                <div
                                    class="flex items-center justify-center w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/20">
                                    <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z">
                                        </path>
                                    </svg>
                                </div>
                            </div>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mb-1">
                                <?php echo esc_html($currently_signed_in); ?></h3>
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                <?php esc_html_e('Currently On Site', 'vms'); ?></p>
                        </div>

                        <!-- This Week -->
                        <div
                            class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] hover:shadow-lg transition-shadow">
                            <div class="flex items-center justify-between mb-4">
                                <div
                                    class="flex items-center justify-center w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-900/20">
                                    <svg class="w-6 h-6 text-purple-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                                        </path>
                                    </svg>
                                </div>
                            </div>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mb-1">
                                <?php echo esc_html($week_visits); ?></h3>
                            <p class="text-sm text-gray-600 dark:text-gray-400"><?php esc_html_e('This Week', 'vms'); ?>
                            </p>
                        </div>

                        <!-- This Month -->
                        <div
                            class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] hover:shadow-lg transition-shadow">
                            <div class="flex items-center justify-between mb-4">
                                <div
                                    class="flex items-center justify-center w-12 h-12 rounded-xl bg-orange-100 dark:bg-orange-900/20">
                                    <svg class="w-6 h-6 text-orange-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                </div>
                            </div>
                            <h3 class="text-3xl font-bold text-gray-900 dark:text-white mb-1">
                                <?php echo esc_html($month_visits); ?></h3>
                            <p class="text-sm text-gray-600 dark:text-gray-400">
                                <?php esc_html_e('This Month', 'vms'); ?></p>
                        </div>
                    </div>

                    <!-- Main Content Grid -->
                    <div class="grid grid-cols-12 gap-4 md:gap-6">

                        <!-- Metrics Overview -->
                        <div class="col-span-12">
                            <?php get_template_part( 'template-parts/content/content', 'metric' ); ?>
                        </div>

                        <!-- Charts and Quick Actions Row -->
                        <div class="col-span-12 xl:col-span-8">
                            <?php get_template_part( 'template-parts/content/content', 'chart' ); ?>
                        </div>

                        <!-- Quick Actions Card -->
                        <div class="col-span-12 xl:col-span-4">
                            <div
                                class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03] h-full">
                                <div class="flex items-center justify-between mb-6">
                                    <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
                                        <?php esc_html_e('Quick Actions', 'vms'); ?>
                                    </h3>
                                    <svg class="w-5 h-5 text-brand-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                    </svg>
                                </div>

                                <div class="grid grid-cols-2 gap-3">
                                    <!-- Register Guest -->
                                    <a href="<?php echo esc_url(home_url('/guests')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl hover:shadow-md transition-all group border border-blue-100 dark:border-blue-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-blue-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Guests', 'vms'); ?>
                                        </span>
                                    </a>

                                    <!-- Accommodation -->
                                    <a href="<?php echo esc_url(home_url('/accommodation')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-xl hover:shadow-md transition-all group border border-green-100 dark:border-green-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-green-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Accommodation', 'vms'); ?>
                                        </span>
                                    </a>

                                    <!-- Suppliers -->
                                    <a href="<?php echo esc_url(home_url('/suppliers')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-xl hover:shadow-md transition-all group border border-purple-100 dark:border-purple-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-purple-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Suppliers', 'vms'); ?>
                                        </span>
                                    </a>

                                    <!-- Reciprocating Members -->
                                    <a href="<?php echo esc_url(home_url('/reciprocating-members')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-xl hover:shadow-md transition-all group border border-orange-100 dark:border-orange-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-orange-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Reciprocating', 'vms'); ?>
                                        </span>
                                    </a>

                                    <!-- Members -->
                                    <a href="<?php echo esc_url(home_url('/members')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-pink-50 to-pink-100 dark:from-pink-900/20 dark:to-pink-800/20 rounded-xl hover:shadow-md transition-all group border border-pink-100 dark:border-pink-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-pink-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Members', 'vms'); ?>
                                        </span>
                                    </a>

                                    <!-- Clubs -->
                                    <a href="<?php echo esc_url(home_url('/clubs')); ?>"
                                        class="flex flex-col items-center justify-center p-4 bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/20 dark:to-indigo-800/20 rounded-xl hover:shadow-md transition-all group border border-indigo-100 dark:border-indigo-800/30">
                                        <div
                                            class="flex items-center justify-center w-12 h-12 mb-3 rounded-full bg-indigo-500 text-white group-hover:scale-110 transition-transform">
                                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                                                </path>
                                            </svg>
                                        </div>
                                        <span class="text-xs font-medium text-gray-800 dark:text-white text-center">
                                            <?php esc_html_e('Clubs', 'vms'); ?>
                                        </span>
                                    </a>
                                </div>

                                <!-- System Status -->
                                <div class="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">
                                            <?php esc_html_e('System Status', 'vms'); ?>
                                        </span>
                                        <div class="flex items-center gap-2">
                                            <span class="flex h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
                                            <span class="text-sm font-medium text-green-600 dark:text-green-400">
                                                <?php esc_html_e('Online', 'vms'); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm text-gray-600 dark:text-gray-400">
                                            <?php esc_html_e('Last Updated', 'vms'); ?>
                                        </span>
                                        <span class="text-xs text-gray-500 dark:text-gray-500">
                                            <?php echo esc_html(current_time('g:i A')); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Activity Card -->
                        <div class="col-span-12 xl:col-span-8">
                            <div
                                class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03]">
                                <div class="flex items-center justify-between mb-6">
                                    <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">
                                        <?php esc_html_e('Recent Check-ins Today', 'vms'); ?>
                                    </h3>
                                    <a href="<?php echo esc_url(home_url('/guests')); ?>"
                                        class="text-sm font-medium text-brand-500 hover:text-brand-600">
                                        <?php esc_html_e('View All', 'vms'); ?> →
                                    </a>
                                </div>

                                <?php if (!empty($recent_checkins)): ?>
                                <div class="space-y-3">
                                    <?php foreach ($recent_checkins as $checkin): ?>
                                    <div
                                        class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                                        <div class="flex items-center gap-3">
                                            <div
                                                class="flex items-center justify-center w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 font-semibold">
                                                <?php echo esc_html(strtoupper(substr($checkin->first_name, 0, 1))); ?>
                                            </div>
                                            <div>
                                                <p class="text-sm font-medium text-gray-900 dark:text-white">
                                                    <?php echo esc_html($checkin->first_name . ' ' . $checkin->last_name); ?>
                                                </p>
                                                <p class="text-xs text-gray-500 dark:text-gray-400">
                                                    <?php echo esc_html($checkin->type); ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-xs font-medium text-gray-900 dark:text-white">
                                                <?php echo esc_html(date('g:i A', strtotime($checkin->sign_in_time))); ?>
                                            </p>
                                            <span
                                                class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">
                                                <?php esc_html_e('Checked In', 'vms'); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <?php else: ?>
                                <div class="text-center py-8">
                                    <svg class="w-16 h-16 mx-auto text-gray-300 dark:text-gray-600 mb-3" fill="none"
                                        stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4">
                                        </path>
                                    </svg>
                                    <p class="text-gray-500 dark:text-gray-400">
                                        <?php esc_html_e('No check-ins yet today', 'vms'); ?>
                                    </p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Activity Summary Card -->
                        <div class="col-span-12 xl:col-span-4">
                            <div
                                class="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-white/[0.03]">
                                <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90 mb-6">
                                    <?php esc_html_e('Today\'s Summary', 'vms'); ?>
                                </h3>

                                <div class="space-y-4">
                                    <!-- Total Visits Progress -->
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="text-sm text-gray-600 dark:text-gray-400">
                                                <?php esc_html_e('Total Visits', 'vms'); ?>
                                            </span>
                                            <span class="text-sm font-semibold text-gray-900 dark:text-white">
                                                <?php echo esc_html($today_visits); ?>
                                            </span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                                            <div class="bg-blue-500 h-2 rounded-full"
                                                style="width: <?php echo min(($today_visits / 50) * 100, 100); ?>%">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Currently On Site Progress -->
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="text-sm text-gray-600 dark:text-gray-400">
                                                <?php esc_html_e('Currently On Site', 'vms'); ?>
                                            </span>
                                            <span class="text-sm font-semibold text-gray-900 dark:text-white">
                                                <?php echo esc_html($currently_signed_in); ?>
                                            </span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                                            <div class="bg-green-500 h-2 rounded-full"
                                                style="width: <?php echo $today_visits > 0 ? min(($currently_signed_in / $today_visits) * 100, 100) : 0; ?>%">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Weekly Progress -->
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="text-sm text-gray-600 dark:text-gray-400">
                                                <?php esc_html_e('Weekly Target', 'vms'); ?>
                                            </span>
                                            <span class="text-sm font-semibold text-gray-900 dark:text-white">
                                                <?php echo esc_html($week_visits); ?>/200
                                            </span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                                            <div class="bg-purple-500 h-2 rounded-full"
                                                style="width: <?php echo min(($week_visits / 200) * 100, 100); ?>%">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Monthly Progress -->
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="text-sm text-gray-600 dark:text-gray-400">
                                                <?php esc_html_e('Monthly Target', 'vms'); ?>
                                            </span>
                                            <span class="text-sm font-semibold text-gray-900 dark:text-white">
                                                <?php echo esc_html($month_visits); ?>/800
                                            </span>
                                        </div>
                                        <div class="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                                            <div class="bg-orange-500 h-2 rounded-full"
                                                style="width: <?php echo min(($month_visits / 800) * 100, 100); ?>%">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Quick Link -->
                                <div class="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                                    <a href="<?php echo esc_url(home_url('/reports')); ?>"
                                        class="flex items-center justify-center w-full px-4 py-2.5 bg-brand-500 hover:bg-brand-600 text-white rounded-lg font-medium transition">
                                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                            </path>
                                        </svg>
                                        <?php esc_html_e('View Detailed Reports', 'vms'); ?>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Activity Table (Full Width) -->
                        <div class="col-span-12">
                            <?php get_template_part( 'template-parts/content/content', 'table' ); ?>
                        </div>
                    </div>
                </div>
            </main>
            <!-- ===== Main Content End ===== -->

            <!-- ===== Footer Start ===== -->
            <?php get_template_part( 'template-parts/content/content', 'footer' ); ?>
            <!-- ===== Footer End ===== -->
        </div>
        <!-- ===== Content Area End ===== -->
    </div>
    <!-- ===== Page Wrapper End ===== -->
</section>

<?php
get_footer();