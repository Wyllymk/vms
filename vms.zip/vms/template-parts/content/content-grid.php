<?php
/**
 * Template part for displaying overlay
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Visitor_Management_System
 */
// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

?>

<div class="absolute right-0 top-0 -z-1 w-full max-w-[250px] xl:max-w-[450px]">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/grid-01.svg" alt="grid" />
</div>
<div class="absolute bottom-0 left-0 -z-1 w-full max-w-[250px] rotate-180 xl:max-w-[450px]">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/grid-01.svg" alt="grid" />
</div>