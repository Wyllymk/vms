<?php
/**
 * Template part for displaying overlay
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Visitor_Management_System
 */
// Exit if accessed directly
defined( 'ABSPATH' ) || exit;

?>

<div class="flex flex-wrap items-center justify-between gap-3 mb-6">

    <h2 class="text-xl font-semibold text-gray-800 dark:text-white/90" x-text="pageName"></h2>

    <!-- <nav>
        <ol class="flex items-center gap-1.5">
            <li>
                <a class="flex items-center gap-1 text-sm text-gray-500 hover:text-brand-500 dark:text-gray-400 dark:hover:text-brand-400"
                    href="<?php echo esc_url( home_url( '/dashboard' ) ); ?>">
                    <?php esc_html_e( 'Home', 'vms' ); ?>
                    <svg class="stroke-current" width="17" height="16" viewBox="0 0 17 16" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.0765 12.667L10.2432 8.50033L6.0765 4.33366" stroke="" stroke-width="1.2"
                            stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </a>
            </li>
            <li class="text-sm text-gray-800 dark:text-white/90" x-text="pageName"></li>
        </ol>
    </nav> -->
</div>